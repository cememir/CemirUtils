from .utils import *

__all__ = ['CemirUtils', 'CemirUtilsConditions', 'CemirPostgreSQL', 'IPGeolocation', 'Dict2Dot', 'CemirUtilsEmail']

author = 'Cem Emir Yüksektepe'
author_ = 'Muslu Yüksektepe'

author_email = 'cememir2017@gmail.com'
author_email_ = 'musluyuksektepe@gmail.com'

years = 2024
