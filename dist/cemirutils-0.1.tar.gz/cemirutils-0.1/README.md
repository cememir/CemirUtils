# CemirUtils
Python'a başlayacaklar veya işini kısaltmak isteyenler için Python fonksiyonlarını daha basit kullanım olarak sunar.
